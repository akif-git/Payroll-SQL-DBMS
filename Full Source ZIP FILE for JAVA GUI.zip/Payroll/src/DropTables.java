import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DropTables {

	public static void main(String[] args) {
		
		Connection conn1 = null;

        try {
            // registers Oracle JDBC driver - though this is no longer required
            // since JDBC 4.0, but added here for backward compatibility
            Class.forName("oracle.jdbc.OracleDriver");
 
           
            String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@oracle.scs.ryerson.ca:1521:orcl";  // that is school Oracle database and you can only use it in the labs
																						
         	
            // String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@localhost:1521:xe";
			/* This XE or local database that you installed on your laptop. 1521 is the default port for database, change according to what you used during installation. 
			xe is the sid, change according to what you setup during installation. */
			
			conn1 = DriverManager.getConnection(dbURL1);
            if (conn1 != null) {
                System.out.println("Connected with connection #1");
            }

            //In your database, you should have a table created already with at least 1 row of data. In this select query example, table testjdbc was already created with at least 2 rows of data with columns NAME and NUM.
			//When you enter your data into the table, please make sure to commit your insertions to ensure your table has the correct data. So the commands that you need to type in Sqldeveloper are
			// CREATE TABLE TESTJDBC (NAME varchar(8), NUM NUMBER);
            // INSERT INTO TESTJDBC VALUES ('ALIS', 67);
            // INSERT INTO TESTJDBC VALUES ('BOB', 345);
            // COMMIT;
            
			
			String dropLocations = "DROP TABLE LOCATIONS";
			String drop2 = "DROP TABLE fulltime";
			String drop3 = "DROP TABLE parttime";
			String drop4 = "DROP TABLE lower_level_employee";
			String drop5 = "DROP TABLE manager";
			String drop6 = "DROP TABLE HR";
			String drop7 = "DROP TABLE dependant";
			String drop8 = "DROP TABLE employee";
			String drop9 = "DROP TABLE payment";
			String drop10 = "DROP TABLE department";
			String drop11 = "DROP TABLE payroll";
			String drop12 = "DROP TABLE login";
							
			try (Statement stmt = conn1.createStatement()) {

				stmt.executeQuery(dropLocations);
				System.out.println("Locations table dropped!");
				stmt.executeQuery(drop2);
				System.out.println("fulltime table dropped!");
				stmt.executeQuery(drop3);
				System.out.println("parttime table dropped!");
				stmt.executeQuery(drop4);
				System.out.println("LL Employee table dropped!");
				stmt.executeQuery(drop5);
				System.out.println("Manager table dropped!");
				stmt.executeQuery(drop6);
				System.out.println("HR table dropped!");
				stmt.executeQuery(drop7);
				System.out.println("Dependant table dropped!");
				stmt.executeQuery(drop8);
				System.out.println("Employee table dropped!");
				stmt.executeQuery(drop9);
				System.out.println("Payment table dropped!");
				stmt.executeQuery(drop10);
				System.out.println("Department table dropped!");
				stmt.executeQuery(drop11);
				System.out.println("Payroll table dropped!");
				stmt.executeQuery(drop12);
				System.out.println("Login table dropped!");

			//If everything was entered correctly, this loop should print each row of data in your TESTJDBC table.
			// And you should see the results as follows:
			// Connected with connection #1
			// ALIS, 67
			// BOB, 345
			
			} catch (SQLException e) {
				System.out.println("Error: " + e.getErrorCode() + ", Tables do not exist, please create tables first");
			}


 
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn1 != null && !conn1.isClosed()) {
                    conn1.close();
                }
     
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
		

	}

}
