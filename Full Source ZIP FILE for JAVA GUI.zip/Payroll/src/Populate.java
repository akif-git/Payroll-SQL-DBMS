import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Populate {

	public static void main(String[] args) {

		
		Connection conn1 = null;

        try {
            // registers Oracle JDBC driver - though this is no longer required
            // since JDBC 4.0, but added here for backward compatibility
            Class.forName("oracle.jdbc.OracleDriver");
 
           
            String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@oracle.scs.ryerson.ca:1521:orcl";  // that is school Oracle database and you can only use it in the labs
																						
         	
            // String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@localhost:1521:xe";
			/* This XE or local database that you installed on your laptop. 1521 is the default port for database, change according to what you used during installation. 
			xe is the sid, change according to what you setup during installation. */
			
			conn1 = DriverManager.getConnection(dbURL1);
            if (conn1 != null) {
                System.out.println("Connected with connection #1");
            }

            //In your database, you should have a table created already with at least 1 row of data. In this select query example, table testjdbc was already created with at least 2 rows of data with columns NAME and NUM.
			//When you enter your data into the table, please make sure to commit your insertions to ensure your table has the correct data. So the commands that you need to type in Sqldeveloper are
			// CREATE TABLE TESTJDBC (NAME varchar(8), NUM NUMBER);
            // INSERT INTO TESTJDBC VALUES ('ALIS', 67);
            // INSERT INTO TESTJDBC VALUES ('BOB', 345);
            // COMMIT;
            
			
			String i1 = "insert into payroll values (1, 5000000.69, 2000000.43, 'Direct Deposit', 'Payed On time')";
			String i2 = "insert into payment values (10, 1, 876.27, 87.3, 0, 0, 0)";
			String i3 = "insert into login values ('billybob@gmail.com', 'Billybob123', 'BillyBob', 'What was your first car?', '1992 Corolla')";
			String i4 = "insert into department values (15, 235, 'Software Department', 'Andrew Ng')";
			String i5 = "insert into employee values (111, 10, 15, 'billybob@gmail.com','Billy Bob',50000.00,TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i6 = "insert into dependant values (111,TO_DATE('2000-08-18','YYYY-MM-DD'), 62, 'Dundas', 'H7Z P0Q', 'Toronto', 'Canada')";
			String i7 = "insert into fulltime values(111, 4166.67)";
			String i8 = "insert into locations values(15, '32 York St', NULL, NULL, '12 Dundas St')";
			String i9 = "insert into payroll values (2, 5000000.69, 2000000.43, 'Certified Cheque', 'Payed On time')";
			String i10 = "insert into payment values (11, 2,1200.23, 100.00, 0, 200.00, 0)";
			String i11 = "insert into login values ('johndoe@gmail.com', '!Password274', 'JohnDoe', 'What was your first pet�s name?', 'Draco')";
			String i12 = "insert into department values (20, 235, 'Software Department', 'Andrew Ng')";
			String i13= "insert into employee values (130, 11, 20, 'johndoe@gmail.com','John Doe',100000.00,TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i14= "insert into dependant values (130, TO_DATE('1954-03-21','YYYY-MM-DD'), 126, 'Bayview', 'MK5 T3B', 'Toronto', 'Canada')";
			String i15= "insert into fulltime values(130, 8333.33)";
			String i16= "insert into locations values(20, '32 York St', NULL, NULL, '12 Dundas St')";
			String i17= "insert into payroll values (3, 5000000.69, 1000000.43, 'Direct Deposit', 'Payed On time')";
			String i18= "insert into payment values (13,3,1100.06, 0, 0, 0, 0)";
			String i19= "insert into login values ('robertsmith@gmail.com', 'Derozan4life', 'RobertSmith', 'In what city did your parents meet?', 'Paris')";
			String i20= "insert into department values (25, 180, 'Law Department', 'Robert Kardashian')";
			String i21= "insert into employee values (140,13, 25, 'robertsmith@gmail.com','Robert Smith',800000.00,TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i22= "insert into dependant values (140, TO_DATE('1972-04-20','YYYY-MM-DD'), 456, 'Kennedy', 'MK5 L6N', 'Toronto', 'Canada')";
			String i23= "insert into fulltime values(140, 6666.67)";
			String i24= "insert into locations values(25, '32 York St', NULL, NULL,NULL)";
			String i25= "insert into payroll values (6, 5000000.69, 500000.67, 'Direct Deposit', 'Payed On time')";
			String i26= "insert into payment values (15,6,1300.00, 35.55, 71.22, 735.60, 14.02)";
			String i27= "insert into login values ('tommylee@gmail.com', '!Sharklover47', 'TommyLee', 'Who did you take to prom?', 'Jessica')";
			String i28= "insert into department values (35, 12, 'HR Department', 'Victoria Willow')";
			String i29= "insert into employee values (160,15, 35, 'tommylee@gmail.com','TommyLee',470000.00,TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i30= "insert into dependant values (160, TO_DATE('1991-12-25','YYYY-MM-DD'), 61, 'Crowchild', 'T1Y 1A7', 'Calgary', 'Canada')";
			String i31= "insert into fulltime values(160, 3916.67)";
			String i32= "insert into locations values(35, NULL, NULL, NULL, '12 Dundas St')";
			String i33= "insert into payroll values (4, 5000000.69, 2000000.43, 'Cash', 'Payed  Late')";
			String i34= "insert into payment values (12, 4, 450.75, 20.25, 0, 0, 0)";
			String i35= "insert into login values ('kaylierodgers@gmail.com', 'kaylirodgers123', 'KayliRodgers', 'What city were you born in?', 'Toronto')";
			String i36= "insert into department values (10, 235, 'Cleaning Department', 'Rachel Davis')";
			String i37= "insert into employee values (120, 12, 10, 'kaylierodgers@gmail.com','kaylie',25000.00,TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i38= "insert into dependant values (120, TO_DATE('1984-06-20','YYYY-MM-DD'), 05, 'George Street', 'P3D P3W', 'Toronto', 'Canada')";
			String i39= "insert into parttime values(120, 12.82, 'Intern')";
			String i40= "insert into locations values(10, NULL,  '20 Eagle Ave', NULL, '50 King St')";
			String i41= "insert into payroll values (5, 5000000.69, 2000000.43, 'Certified Cheque', 'Payed On time')";
			String i42= "insert into payment values (14, 5, 3200.00,110.00, 300.00, 600.00, 10000.00)";
			String i43= "insert into login values ('stevenadams@gmail.com', 'Stevenadams123', 'StevenAdams', 'Favorite basketball team?', 'OKC Thunder')";
			String i44= "insert into department values (40, 300, 'Finance Department', 'Josh Albert')";
			String i45= "insert into employee values (150, 14, 40, 'stevenadams@gmail.com','Stevens Adams',120000.00, TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i46= "insert into dependant values (150, TO_DATE('1998-03-05','YYYY-MM-DD'), 09, 'Sky Drive', 'G9J 10Q', 'Vancouver', 'Canada')";
			String i47= "insert into fulltime values(150, 10000.00)";
			String i48= "insert into locations values(40,NULL, NULL, NULL, '12 Dundas St')";
			String i49= "insert into payroll values (7, 5000000.69, 2000000.43, 'Direct Deposit', 'Payed On time')";
			String i50= "insert into payment values (30, 7, 2200.00, 94.87, 0, 0, 0)";
			String i51= "insert into login values ('JakePaul@gmail.com', 'JakePaul123', 'JakePaul', 'Favorite high school teacher?', 'Mr. Josh')";
			String i52= "insert into department values (18, 235, 'Software Department', 'Andrew Ng')";
			String i53= "insert into employee values (141, 10, 18, 'JakePaul@gmail.com','Jake Paul',52800.00, TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i54=  "insert into dependant values (141, TO_DATE('2000-01-12','YYYY-MM-DD'), 32, 'Queen Street', 'J8F P0Q', 'Toronto', 'Canada')";
			String i55= "insert into fulltime values(141, 4400.00)";
			String i56= "insert into locations values(18, '32 York St', NULL, NULL, '12 Dundas St')";
			String i57= "insert into payroll values (9, 3000000.69, 4000000.43, 'Cash', 'Payed  Late')";
			String i58= "insert into payment values (33, 9, 450.75, 20.25, 0, 0, 0)";
			String i59= "insert into login values ('kayrodgers1@gmail.com', 'karodgers1234', 'KRodgers5', 'What city were you born in?', 'Toronto')";
			String i60= "insert into department values (99, 255, 'Cleaning Department', 'Rachel Davis')";
			String i61= "insert into employee values (121, 33, 99, 'kayrodgers1@gmail.com','kaylie',25000.00, TO_DATE('2021-08-05','YYYY-MM-DD'))";
			String i62= "insert into dependant values (121, TO_DATE('1984-06-20','YYYY-MM-DD'), 05, 'George Street', 'P3D P3W', 'Toronto', 'Canada')";
			String i63= "insert into parttime values(121, 12.82, 'Intern')";
			String i64= "insert into locations values(99, NULL,  '20 Eagle Ave', NULL, '12 Dundas St')";
							
			try (Statement stmt = conn1.createStatement()) {

				stmt.executeQuery(i1);
				stmt.executeQuery(i2);
				stmt.executeQuery(i3);
				stmt.executeQuery(i4);
				stmt.executeQuery(i5);
				stmt.executeQuery(i6);
				stmt.executeQuery(i7);
				stmt.executeQuery(i8);
				stmt.executeQuery(i9);
				stmt.executeQuery(i10);
				stmt.executeQuery(i11);
				stmt.executeQuery(i12);
				stmt.executeQuery(i13);
				stmt.executeQuery(i14);
				stmt.executeQuery(i15);
				stmt.executeQuery(i16);
				stmt.executeQuery(i17);
				stmt.executeQuery(i18);
				stmt.executeQuery(i19);
				stmt.executeQuery(i20);
				stmt.executeQuery(i21);
				stmt.executeQuery(i22);
				stmt.executeQuery(i23);
				stmt.executeQuery(i24);
				stmt.executeQuery(i25);
				stmt.executeQuery(i26);
				stmt.executeQuery(i27);
				stmt.executeQuery(i28);
				stmt.executeQuery(i29);
				stmt.executeQuery(i30);
				stmt.executeQuery(i31);
				stmt.executeQuery(i32);
				stmt.executeQuery(i33);
				stmt.executeQuery(i34);
				stmt.executeQuery(i35);
				stmt.executeQuery(i36);
				stmt.executeQuery(i37);
				stmt.executeQuery(i38);
				stmt.executeQuery(i39);
				stmt.executeQuery(i40);
				stmt.executeQuery(i41);
				stmt.executeQuery(i42);
				stmt.executeQuery(i43);
				stmt.executeQuery(i44);
				stmt.executeQuery(i45);
				stmt.executeQuery(i46);
				stmt.executeQuery(i47);
				stmt.executeQuery(i48);
				stmt.executeQuery(i49);
				stmt.executeQuery(i50);
				stmt.executeQuery(i51);
				stmt.executeQuery(i52);
				stmt.executeQuery(i53);
				stmt.executeQuery(i54);
				stmt.executeQuery(i55);
				stmt.executeQuery(i56);
				stmt.executeQuery(i57);
				stmt.executeQuery(i58);
				stmt.executeQuery(i59);
				stmt.executeQuery(i60);
				stmt.executeQuery(i61);
				stmt.executeQuery(i62);
				stmt.executeQuery(i63);
				stmt.executeQuery(i64);
			
			//	for (int i = 14; i < 57; i++) {
				//	String x = "i"+i;
					//System.out.println(x);
					//stmt.executeQuery(x);	
				//}
			//If everything was entered correctly, this loop should print each row of data in your TESTJDBC table.
			// And you should see the results as follows:
			// Connected with connection #1
			// ALIS, 67
			// BOB, 345
			
			} catch (SQLException e) {
				System.out.println("Error: " + e.getErrorCode() + ", Already populated or tables do not exist.");
			}
			


 
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn1 != null && !conn1.isClosed()) {
                    conn1.close();
                }
     
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
		

	}

}
