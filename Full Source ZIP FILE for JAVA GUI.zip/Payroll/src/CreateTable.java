import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class CreateTable {

	public static void main(String[] args) {
		Connection conn1 = null;

        try {
            // registers Oracle JDBC driver - though this is no longer required
            // since JDBC 4.0, but added here for backward compatibility
            Class.forName("oracle.jdbc.OracleDriver");
 
           
            String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@oracle.scs.ryerson.ca:1521:orcl";  // that is school Oracle database and you can only use it in the labs
																						
         	
            // String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@localhost:1521:xe";
			/* This XE or local database that you installed on your laptop. 1521 is the default port for database, change according to what you used during installation. 
			xe is the sid, change according to what you setup during installation. */
			
			conn1 = DriverManager.getConnection(dbURL1);
            if (conn1 != null) {
                System.out.println("Connected with connection #1");
            }

            //In your database, you should have a table created already with at least 1 row of data. In this select query example, table testjdbc was already created with at least 2 rows of data with columns NAME and NUM.
			//When you enter your data into the table, please make sure to commit your insertions to ensure your table has the correct data. So the commands that you need to type in Sqldeveloper are
			// CREATE TABLE TESTJDBC (NAME varchar(8), NUM NUMBER);
            // INSERT INTO TESTJDBC VALUES ('ALIS', 67);
            // INSERT INTO TESTJDBC VALUES ('BOB', 345);
            // COMMIT;
            
            String query1 = "CREATE TABLE DISPATCHES("
            	      + "ProductName VARCHAR (20) NOT NULL, "
            	      + "CustomerName VARCHAR (20) NOT NULL, "
            	      + "DispatchDate date, "
            	      + "DeliveryTime timestamp, "
            	      + "Price INT, "
            	      + "Location varchar(20))";
            
            String payroll = "CREATE TABLE payroll("
            		+ "PAYROLL_ID INT PRIMARY KEY, "
            		+ "TotalCompanyRevenue FLOAT, "
            		+ "PaymentBudget FLOAT, "
            		+ "PayrollType VARCHAR2(20), "
            		+ "PayrollDesc VARCHAR2(100))";
            
            String payment = "CREATE TABLE payment("
            		+ "PAY_ID INT PRIMARY KEY, "
            		+ "PAYROLL_ID_FOREIGN INT, "
            		+ "BiWeeklySalary FLOAT, "
            		+ "OvertimeAmount FLOAT, "
            		+ "Claimable_Expenses FLOAT, "
            		+ "VacationPay FLOAT, "
            		+ "BonusAndComissions FLOAT, "
            		+ "FOREIGN KEY(PAYROLL_ID_FOREIGN) REFERENCES payroll(PAYROLL_ID) ON DELETE CASCADE)";
            
            String department = "CREATE TABLE department("
            		+ "DEPARTMENT_ID INT PRIMARY KEY, "
            		+ "NumberOfEmployees INT NOT NULL, "
            		+ "DEP_NAME VARCHAR2(20), "
            		+ "DEP_MANAGER VARCHAR2(20))";
            
            String login = "CREATE TABLE login("
            		+ "EMAIL VARCHAR(35) PRIMARY KEY, "
            		+ "Password1 VARCHAR2(20), "
            		+ "Username VARCHAR2(12), "
            		+ "Seq_questions VARCHAR(600), "
            		+ "Answers VARCHAR(30))";
            
            String ll_employee = "CREATE TABLE lower_level_employee("
            		+ "EMAIL VARCHAR(35) PRIMARY KEY REFERENCES login(EMAIL), "
            		+ "RestrictedAccess int)";
            
            String manager = "CREATE TABLE manager("
            		+ "EMAIL VARCHAR(35) PRIMARY KEY REFERENCES login(EMAIL), "
            		+ "ViewDownAccess int)";
            
            String HR = "CREATE TABLE HR("
            		+ "EMAIL VARCHAR(35) PRIMARY KEY REFERENCES login(EMAIL), "
            		+ "SuperAccess int)";
            
            String employee = "CREATE TABLE employee("
            		+ "EMP_ID  INT PRIMARY KEY, "
            		+ "PAY_ID_FOREIGN INT, "
            		+ "DEPT_ID_FOREIGN INT, "
            		+ "EMAIL_FOREIGN VARCHAR(35), "
            		+ "E_Name  VARCHAR2(20), "
            		+ "E_Salary FLOAT, "
            		+ "Pay_Date DATE, "
            		+ "FOREIGN KEY (PAY_ID_FOREIGN) REFERENCES payment(PAY_ID) ON DELETE CASCADE, "
            		+ "FOREIGN KEY (DEPT_ID_FOREIGN) REFERENCES department(DEPARTMENT_ID) ON DELETE CASCADE, "
            		+ "FOREIGN KEY (EMAIL_FOREIGN) REFERENCES login(email) ON DELETE CASCADE)";
            
            String parttime = "CREATE TABLE parttime("
            		+ "EMP_ID INT REFERENCES employee(EMP_ID), "
            		+ "HourlyRate FLOAT, "
            		+ "Type VARCHAR(20), "
            		+ "PRIMARY KEY(EMP_ID)) ";
            
            String fulltime = "CREATE TABLE fulltime("
            		+ "EMP_ID INT REFERENCES employee(EMP_ID), "
            		+ "MonthlyRate FLOAT, "
            		+ "PRIMARY KEY(EMP_ID)) ";
            
            String locations = "CREATE TABLE locations("
            		+ "DEPARTMENT_ID INT PRIMARY KEY REFERENCES department(DEPARTMENT_ID), "
            		+ "West_Department VARCHAR2(20), "
            		+ "East_Department VARCHAR2(20), "
            		+ "North_Department VARCHAR2(20), "
            		+ "South_Department VARCHAR2(20))";
            
            String dependant= "CREATE TABLE dependant("
            		+ "EMP_ID INT REFERENCES employee(EMP_ID), "
            		+ "Birthdate DATE, "
            		+ "StreetNumber INT, "
            		+ "StreetName VARCHAR(20), "
            		+ "PostalCode VARCHAR(20), "
            		+ "City VARCHAR(20), "
            		+ "Country VARCHAR(20), "
            		+ "PRIMARY KEY(EMP_ID))";
            
			try (Statement stmt = conn1.createStatement()) {

			stmt.executeQuery(payroll);
			System.out.println("Payroll Table Created......");
			stmt.executeQuery(payment);
			System.out.println("Payment Table Created......");
			stmt.executeQuery(department);
			System.out.println("Department Table Created......");
			stmt.executeQuery(login);
			System.out.println("Login Table Created......");
			stmt.executeQuery(ll_employee);
			System.out.println("Lower level employee Table Created......");
			stmt.executeQuery(manager);
			System.out.println("Manager Table Created......");
			stmt.executeQuery(HR);
			System.out.println("HR Table Created......");
			stmt.executeQuery(employee);
			System.out.println("Employee Table Created......");
			stmt.executeQuery(parttime);
			System.out.println("Part time Table Created......");
			stmt.executeQuery(fulltime);
			System.out.println("Full time Table Created......");
			stmt.executeQuery(locations);
			System.out.println("Locations Table Created......");
			stmt.executeQuery(dependant);
			System.out.println("Dependant Table Created......");

			//If everything was entered correctly, this loop should print each row of data in your TESTJDBC table.
			// And you should see the results as follows:
			// Connected with connection #1
			// ALIS, 67
			// BOB, 345
			
			} catch (SQLException e) {
				System.out.println("ERROR: " + e.getErrorCode() + " , Table already exists. Please drop tables first then create");
			}
			
			
 
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn1 != null && !conn1.isClosed()) {
                    conn1.close();
                }
     
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
			
		

	}

}
