import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Queries {

	public static void main(String[] args) {
		
		Connection conn1 = null;

        try {
            // registers Oracle JDBC driver - though this is no longer required
            // since JDBC 4.0, but added here for backward compatibility
            Class.forName("oracle.jdbc.OracleDriver");
 
           
            String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@oracle.scs.ryerson.ca:1521:orcl";  // that is school Oracle database and you can only use it in the labs
																						
         	
            // String dbURL1 = "jdbc:oracle:thin:amimtiaz/08184438@localhost:1521:xe";
			/* This XE or local database that you installed on your laptop. 1521 is the default port for database, change according to what you used during installation. 
			xe is the sid, change according to what you setup during installation. */
			
			conn1 = DriverManager.getConnection(dbURL1);
            if (conn1 != null) {
                System.out.println("Connected with connection #1");
            }

            //In your database, you should have a table created already with at least 1 row of data. In this select query example, table testjdbc was already created with at least 2 rows of data with columns NAME and NUM.
			//When you enter your data into the table, please make sure to commit your insertions to ensure your table has the correct data. So the commands that you need to type in Sqldeveloper are
			// CREATE TABLE TESTJDBC (NAME varchar(8), NUM NUMBER);
            // INSERT INTO TESTJDBC VALUES ('ALIS', 67);
            // INSERT INTO TESTJDBC VALUES ('BOB', 345);
            // COMMIT;
         //   String query = "select NAME, NUM from TESTJDBC";
			
			String query = "select E_NAME from EMPLOYEE";
							
			try (Statement stmt = conn1.createStatement()) {
			System.out.println("List all employee names");
			ResultSet rs = stmt.executeQuery(query);

			
			while (rs.next()) {
				String name = rs.getString("E_NAME");
				System.out.println("Employee name: " + name + " ");
			}
			

			
			} catch (SQLException e) {
				System.out.println(e.getErrorCode());
			}
			
			String query2 = "SELECT EMP_ID, E_name\r\n"
					+ "FROM employee \r\n"
					+ "WHERE EXISTS\r\n"
					+ "(SELECT DEP_NAME\r\n"
					+ "FROM department\r\n"
					+ "WHERE DEP_NAME = 'Software Department')";
			
			
			try (Statement stmt1 = conn1.createStatement()) {
				ResultSet rs2 = stmt1.executeQuery(query2);
				System.out.println("All employees who work in the software department:");
				while (rs2.next()) {
					int num = rs2.getInt("EMP_ID");
					String name = rs2.getString("E_name");
					System.out.println("Emp name: " + name + " | Emp ID: " + num);
				}
			
				
			}
			
			catch (SQLException e) {
				System.out.println(e.getErrorCode());
			}
			
			String query3 = "SELECT  employee.E_name, employee.E_salary, dependant.city\r\n"
					+ "FROM   employee\r\n"
					+ "INNER JOIN dependant ON employee.EMP_ID=dependant.emp_id\r\n"
					+ "WHERE employee.E_salary > 100000\r\n"
					+ "ORDER BY employee.e_salary asc";
			System.out.println("Display the city of all the employee's who make over 100k");
			try (Statement stmt = conn1.createStatement()) {
				ResultSet rs3 = stmt.executeQuery(query3);
				while (rs3.next()) {
					String name = rs3.getString("E_name");
					int num = rs3.getInt("E_salary");
					String city = rs3.getString("city");
					System.out.println("Emp name: " + name + " | Salary: " + num + " | City: " +  city);
				} 
				
			}
			catch (SQLException e) {
				System.out.println(e.getErrorCode());
			}
			
			
			


 
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (conn1 != null && !conn1.isClosed()) {
                    conn1.close();
                }
     
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
		

	}

}
